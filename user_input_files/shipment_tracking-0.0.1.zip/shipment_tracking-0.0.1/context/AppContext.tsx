
import React, { createContext, useState, useEffect, useContext, useMemo, useCallback } from 'react';
import { User, Role, Product, Region, Driver, Shipment, ProductPrice, Notification, NotificationCategory, ShipmentProduct, ShipmentStatus } from '../types';
import { supabase } from '../utils/supabaseClient';
import type { Session } from '@supabase/supabase-js';
import { Database } from '../supabase/database.types';

// Type alias for Supabase row types
type UserRow = Database['public']['Tables']['users']['Row'];
type ProductRow = Database['public']['Tables']['products']['Row'];
type DriverRow = Database['public']['Tables']['drivers']['Row'];
type RegionRow = Database['public']['Tables']['regions']['Row'];
type ShipmentRow = Database['public']['Tables']['shipments']['Row'];
type ShipmentProductRow = Database['public']['Tables']['shipment_products']['Row'];
type ProductPriceRow = Database['public']['Tables']['product_prices']['Row'];
type NotificationRow = Database['public']['Tables']['notifications']['Row'];


// --- Data Mapping Functions ---
const userFromRow = (row: UserRow): User => ({
    id: row.id,
    username: row.username,
    role: row.role as Role,
    isActive: row.is_active ?? true,
    createdAt: row.created_at ?? undefined,
});

const productFromRow = (row: ProductRow): Product => ({
    id: row.id,
    name: row.name,
    isActive: row.is_active ?? true,
});

const driverFromRow = (row: DriverRow): Driver => ({
    id: row.id,
    name: row.name,
    plateNumber: row.plate_number,
    isActive: row.is_active ?? true,
});

const regionFromRow = (row: RegionRow): Region => ({
    id: row.id,
    name: row.name,
    dieselLiterPrice: row.diesel_liter_price,
    dieselLiters: row.diesel_liters,
    zaitriFee: row.zaitri_fee,
});

const shipmentFromRow = (row: ShipmentRow, products: ShipmentProduct[]): Shipment => ({
    id: row.id,
    salesOrder: row.sales_order,
    orderDate: row.order_date,
    entryTimestamp: row.entry_timestamp,
    regionId: row.region_id,
    driverId: row.driver_id,
    status: row.status as ShipmentStatus,
    products,
    totalDiesel: row.total_diesel ?? undefined,
    totalWage: row.total_wage ?? undefined,
    zaitriFee: row.zaitri_fee ?? undefined,
    adminExpenses: row.admin_expenses ?? undefined,
    dueAmount: row.due_amount ?? undefined,
    damagedValue: row.damaged_value ?? undefined,
    shortageValue: row.shortage_value ?? undefined,
    roadExpenses: row.road_expenses ?? undefined,
    dueAmountAfterDiscount: row.due_amount_after_discount ?? undefined,
    otherAmounts: row.other_amounts ?? undefined,
    improvementBonds: row.improvement_bonds ?? undefined,
    eveningAllowance: row.evening_allowance ?? undefined,
    totalDueAmount: row.total_due_amount ?? undefined,
    taxRate: row.tax_rate ?? undefined,
    totalTax: row.total_tax ?? undefined,
    transferNumber: row.transfer_number ?? undefined,
    transferDate: row.transfer_date ?? undefined,
    modifiedBy: row.modified_by ?? undefined,
    modifiedAt: row.modified_at ?? undefined,
    deductionsEditedBy: row.deductions_edited_by ?? undefined,
    deductionsEditedAt: row.deductions_edited_at ?? undefined,
    hasMissingPrices: row.has_missing_prices,
    createdBy: row.created_by ?? undefined,
    createdAt: row.created_at ?? undefined,
});

const shipmentProductFromRow = (row: ShipmentProductRow): ShipmentProduct => ({
    productId: row.product_id,
    productName: row.product_name,
    cartonCount: row.carton_count,
    productWagePrice: row.product_wage_price ?? undefined,
});

const priceFromRow = (row: ProductPriceRow): ProductPrice => ({
    id: row.id,
    regionId: row.region_id,
    productId: row.product_id,
    price: row.price,
});

const notificationFromRow = (row: NotificationRow): Notification => ({
    id: row.id,
    message: row.message,
    timestamp: row.timestamp,
    read: row.read ?? false,
    category: row.category as NotificationCategory,
    targetRoles: (row.target_roles as Role[]) ?? undefined,
    targetUserIds: row.target_user_ids ?? undefined,
});

const shipmentToRow = (shipment: Partial<Shipment>): Partial<Database['public']['Tables']['shipments']['Update']> => {
    const keyMap: { [K in keyof Shipment]?: keyof Database['public']['Tables']['shipments']['Update'] } = {
        salesOrder: 'sales_order',
        orderDate: 'order_date',
        entryTimestamp: 'entry_timestamp',
        regionId: 'region_id',
        driverId: 'driver_id',
        status: 'status',
        totalDiesel: 'total_diesel',
        totalWage: 'total_wage',
        zaitriFee: 'zaitri_fee',
        adminExpenses: 'admin_expenses',
        dueAmount: 'due_amount',
        damagedValue: 'damaged_value',
        shortageValue: 'shortage_value',
        roadExpenses: 'road_expenses',
        dueAmountAfterDiscount: 'due_amount_after_discount',
        otherAmounts: 'other_amounts',
        improvementBonds: 'improvement_bonds',
        eveningAllowance: 'evening_allowance',
        totalDueAmount: 'total_due_amount',
        taxRate: 'tax_rate',
        totalTax: 'total_tax',
        transferNumber: 'transfer_number',
        transferDate: 'transfer_date',
        modifiedBy: 'modified_by',
        modifiedAt: 'modified_at',
        deductionsEditedBy: 'deductions_edited_by',
        deductionsEditedAt: 'deductions_edited_at',
        hasMissingPrices: 'has_missing_prices',
    };

    const rowData: Partial<Database['public']['Tables']['shipments']['Update']> = {};
    for (const key in shipment) {
        if (Object.prototype.hasOwnProperty.call(shipment, key) && keyMap[key as keyof Shipment]) {
            const dbKey = keyMap[key as keyof Shipment]!;
            const value = shipment[key as keyof Shipment];
            if (value !== undefined) {
                (rowData as any)[dbKey] = value;
            }
        }
    }
    return rowData;
};


interface AppContextType {
    currentUser: User | null;
    handleLogout: () => Promise<void>;
    users: User[];
    addUser: (userData: Omit<User, 'id'>, password: string) => Promise<User | null>;
    updateUser: (userId: string, updates: Partial<User>) => Promise<void>;
    products: Product[];
    addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
    updateProduct: (productId: string, updates: Partial<Product>) => Promise<void>;
    drivers: Driver[];
    addDriver: (driver: Omit<Driver, 'id'>) => Promise<void>;
    updateDriver: (driverId: number, updates: Partial<Driver>) => Promise<void>;
    deleteDriver: (driverId: number) => Promise<void>;
    regions: Region[];
    addRegion: (region: Omit<Region, 'id'>) => Promise<void>;
    updateRegion: (regionId: string, updates: Partial<Region>) => Promise<void>;
    deleteRegion: (regionId: string) => Promise<void>;
    shipments: Shipment[];
    addShipment: (shipment: Omit<Shipment, 'id'>) => Promise<void>;
    updateShipment: (shipmentId: string, updates: Partial<Shipment>) => Promise<void>;
    productPrices: ProductPrice[];
    addProductPrice: (price: Omit<ProductPrice, 'id'>) => Promise<void>;
    updateProductPrice: (priceId: string, updates: Partial<ProductPrice>) => Promise<void>;
    deleteProductPrice: (priceId: string) => Promise<void>;
    notifications: Notification[];
    addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => Promise<void>;
    markNotificationAsRead: (notificationId: string) => Promise<void>;
    markAllNotificationsAsRead: () => Promise<void>;
    accountantPrintAccess: boolean;
    setAccountantPrintAccess: React.Dispatch<React.SetStateAction<boolean>>;
    isPrintHeaderEnabled: boolean;
    setIsPrintHeaderEnabled: React.Dispatch<React.SetStateAction<boolean>>;
    appName: string;
    setAppName: React.Dispatch<React.SetStateAction<string>>;
    companyName: string;
    setCompanyName: React.Dispatch<React.SetStateAction<string>>;
    companyAddress: string;
    setCompanyAddress: React.Dispatch<React.SetStateAction<string>>;
    companyPhone: string;
    setCompanyPhone: React.Dispatch<React.SetStateAction<string>>;
    companyLogo: string;
    setCompanyLogo: React.Dispatch<React.SetStateAction<string>>;
    isTimeWidgetVisible: boolean;
    setIsTimeWidgetVisible: React.Dispatch<React.SetStateAction<boolean>>;
    loading: boolean;
    error: string | null;
    isOnline: boolean;
    isSyncing: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const getFromCache = <T,>(key: string, defaultValue: T): T => {
    try {
        const cached = localStorage.getItem(key);
        return cached ? JSON.parse(cached) : defaultValue;
    } catch (e) {
        console.error("Error reading from cache", e);
        return defaultValue;
    }
}
const setToCache = <T,>(key: string, value: T) => {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
        console.error("Error writing to cache", e);
    }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const [isSyncing, setIsSyncing] = useState(false);
    
    // Data states with initial hydration from cache
    const [users, setUsers] = useState<User[]>(() => getFromCache('users', []));
    const [products, setProducts] = useState<Product[]>(() => getFromCache('products', []));
    const [drivers, setDrivers] = useState<Driver[]>(() => getFromCache('drivers', []));
    const [regions, setRegions] = useState<Region[]>(() => getFromCache('regions', []));
    const [shipments, setShipments] = useState<Shipment[]>(() => getFromCache('shipments', []));
    const [productPrices, setProductPrices] = useState<ProductPrice[]>(() => getFromCache('productPrices', []));
    const [notifications, setNotifications] = useState<Notification[]>(() => getFromCache('notifications', []));

    // Settings states (persisted to localStorage)
    const [accountantPrintAccess, setAccountantPrintAccess] = useState<boolean>(() => JSON.parse(localStorage.getItem('accountantPrintAccess') || 'false'));
    const [isPrintHeaderEnabled, setIsPrintHeaderEnabled] = useState<boolean>(() => JSON.parse(localStorage.getItem('isPrintHeaderEnabled') || 'true'));
    const [appName, setAppName] = useState<string>(() => localStorage.getItem('appName') || 'تتبع الشحنات');
    const [companyName, setCompanyName] = useState<string>(() => localStorage.getItem('companyName') || 'اسم الشركة');
    const [companyAddress, setCompanyAddress] = useState<string>(() => localStorage.getItem('companyAddress') || 'عنوان الشركة');
    const [companyPhone, setCompanyPhone] = useState<string>(() => localStorage.getItem('companyPhone') || 'رقم الهاتف');
    const [companyLogo, setCompanyLogo] = useState<string>(() => localStorage.getItem('companyLogo') || '');
    const [isTimeWidgetVisible, setIsTimeWidgetVisible] = useState<boolean>(() => JSON.parse(localStorage.getItem('isTimeWidgetVisible') || 'true'));

    useEffect(() => { localStorage.setItem('accountantPrintAccess', JSON.stringify(accountantPrintAccess)); }, [accountantPrintAccess]);
    useEffect(() => { localStorage.setItem('isPrintHeaderEnabled', JSON.stringify(isPrintHeaderEnabled)); }, [isPrintHeaderEnabled]);
    useEffect(() => { localStorage.setItem('appName', appName); }, [appName]);
    useEffect(() => { localStorage.setItem('companyName', companyName); }, [companyName]);
    useEffect(() => { localStorage.setItem('companyAddress', companyAddress); }, [companyAddress]);
    useEffect(() => { localStorage.setItem('companyPhone', companyPhone); }, [companyPhone]);
    useEffect(() => { localStorage.setItem('companyLogo', companyLogo); }, [companyLogo]);
    useEffect(() => { localStorage.setItem('isTimeWidgetVisible', JSON.stringify(isTimeWidgetVisible)); }, [isTimeWidgetVisible]);


    const fetchAllData = useCallback(async () => {
        if (!navigator.onLine) {
            console.log("Offline mode: Skipping fetch.");
            setLoading(false);
            return;
        }
        setError(null);
        try {
            const [usersRes, productsRes, driversRes, regionsRes, shipmentsRes, shipmentProductsRes, pricesRes, notificationsRes] = await Promise.all([
                supabase.from('users').select('*'),
                supabase.from('products').select('*'),
                supabase.from('drivers').select('*'),
                supabase.from('regions').select('*'),
                supabase.from('shipments').select('*'),
                supabase.from('shipment_products').select('*'),
                supabase.from('product_prices').select('*'),
                supabase.from('notifications').select('*').order('timestamp', { ascending: false }),
            ]);

            const responses = [usersRes, productsRes, driversRes, regionsRes, shipmentsRes, shipmentProductsRes, pricesRes, notificationsRes];
            for (const res of responses) { if (res.error) throw res.error; }

            const newUsers = usersRes.data!.map(userFromRow);
            const newProducts = productsRes.data!.map(productFromRow);
            const newDrivers = driversRes.data!.map(driverFromRow);
            const newRegions = regionsRes.data!.map(regionFromRow);
            const newPrices = pricesRes.data!.map(priceFromRow);
            const newNotifications = notificationsRes.data!.map(notificationFromRow);
            const shipmentProductsByShipmentId = shipmentProductsRes.data!.reduce((acc, sp) => {
                if (!acc[sp.shipment_id]) { acc[sp.shipment_id] = []; }
                acc[sp.shipment_id].push(shipmentProductFromRow(sp));
                return acc;
            }, {} as Record<string, ShipmentProduct[]>);
            const newShipments = shipmentsRes.data!.map(s => shipmentFromRow(s, shipmentProductsByShipmentId[s.id] || []));
            
            setUsers(newUsers); setToCache('users', newUsers);
            setProducts(newProducts); setToCache('products', newProducts);
            setDrivers(newDrivers); setToCache('drivers', newDrivers);
            setRegions(newRegions); setToCache('regions', newRegions);
            setProductPrices(newPrices); setToCache('productPrices', newPrices);
            setNotifications(newNotifications); setToCache('notifications', newNotifications);
            
            // Retrieve true pending shipments from the mutation queue, not the general shipments cache
            // This ensures that once a shipment is synced and removed from the queue, it's replaced by the server version.
            const mutationQueue = getFromCache<{type: string, payload: any}[]>('mutationQueue', []);
            const pendingShipments = mutationQueue
                .filter(m => m.type === 'addShipment')
                .map(m => m.payload as Shipment);

            // De-duplicate: although pending shipments have "offline-" IDs, we check just in case
            // But mostly we just want to layer pending on top of server data.
            const finalShipments = [...pendingShipments, ...newShipments];
            
            setShipments(finalShipments); 
            setToCache('shipments', finalShipments);

        } catch (err: any) {
            console.error("Error fetching data:", err);
            setError(`فشل تحميل البيانات: ${err.message}.`);
        }
    }, []);

    const syncOfflineMutations = useCallback(async () => {
        const mutationQueue = getFromCache<{ type: string, payload: any }[]>('mutationQueue', []);
        if (mutationQueue.length === 0) return;

        setIsSyncing(true);
        console.log(`Starting sync of ${mutationQueue.length} offline actions.`);

        const offlineToRealIdMap: Record<string, string> = {};
        const successfullySyncedIndices: number[] = [];

        for (const [index, mutation] of mutationQueue.entries()) {
            try {
                if (mutation.type === 'addShipment') {
                    // Strip the offline ID and pending flag. DB will generate a new UUID.
                    const { products, id: offlineId, isPendingSync, ...shipmentData } = mutation.payload;
                    
                    const shipmentRow = shipmentToRow(shipmentData);
                    if (!shipmentRow.created_by && currentUser?.id) {
                        shipmentRow.created_by = currentUser.id;
                    }

                    // Insert shipment and get new ID
                    const { data: newShipmentData, error: shipmentError } = await supabase
                        .from('shipments')
                        .insert(shipmentRow as any)
                        .select()
                        .single();
                    
                    if (shipmentError) throw shipmentError;

                    // Store mapping: offlineId -> real UUID
                    if (offlineId && String(offlineId).startsWith('offline-')) {
                        offlineToRealIdMap[offlineId] = newShipmentData.id;
                    }

                    // Insert products with NEW shipment ID
                    const shipmentProductsToInsert = products.map((p: ShipmentProduct) => ({
                         shipment_id: newShipmentData.id,
                         product_id: p.productId, 
                         product_name: p.productName, 
                         carton_count: p.cartonCount, 
                         product_wage_price: p.productWagePrice 
                    }));
                    
                    const { error: productsError } = await supabase.from('shipment_products').insert(shipmentProductsToInsert);
                    if (productsError) throw productsError;

                } else if (mutation.type === 'updateShipment') {
                    let { shipmentId, updates } = mutation.payload;

                    // If this update is for an offline shipment we just synced, map the ID
                    if (offlineToRealIdMap[shipmentId]) {
                        shipmentId = offlineToRealIdMap[shipmentId];
                    }

                    const { products, ...shipmentUpdates } = updates;
                    const updateRow = shipmentToRow(shipmentUpdates);
                    
                    const { error } = await supabase.from('shipments').update(updateRow).eq('id', shipmentId);
                    if (error) throw error;
                }

                successfullySyncedIndices.push(index);
            } catch (err) {
                console.error('Failed to sync mutation:', mutation, err);
                // Keep failed mutation in queue for retry
            }
        }
        
        // Remove successfully synced items
        const newQueue = mutationQueue.filter((_, index) => !successfullySyncedIndices.includes(index));
        setToCache('mutationQueue', newQueue);
        
        // Refresh data from server to get the new IDs and clean states
        await fetchAllData();
        setIsSyncing(false);
        console.log('Sync finished.');
    }, [currentUser, fetchAllData]);

    // Online/Offline listener
    useEffect(() => {
        const handleOnline = () => {
            setIsOnline(true);
            syncOfflineMutations();
        };
        const handleOffline = () => setIsOnline(false);

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, [syncOfflineMutations]);

    const clearData = useCallback(() => {
        setUsers([]);
        setProducts([]);
        setDrivers([]);
        setRegions([]);
        setShipments([]);
        setProductPrices([]);
        setNotifications([]);
    }, []);
    
    useEffect(() => {
        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session: Session | null) => {
            if (session?.user) {
                setLoading(true);
                const { data, error } = await supabase.from('users').select('*').eq('id', session.user.id).single();
                
                if (error) {
                    console.error("Error fetching profile:", error);
                    setError("لم يتم العثور على ملف المستخدم. يرجى الاتصال بالمسؤول.");
                    await supabase.auth.signOut();
                    setLoading(false);
                } else if (data) {
                    setCurrentUser(userFromRow(data));
                    await fetchAllData();
                    setLoading(false);
                }
            } else {
                clearData();
                setCurrentUser(null);
                setLoading(false);
            }
        });

        return () => subscription.unsubscribe();
    }, [fetchAllData, clearData]);

    const handleLogout = useCallback(async () => {
        const { error } = await supabase.auth.signOut();
        if (error) {
            console.error("Error signing out:", error);
        }
    }, []);

    const addProduct = useCallback(async (product: Omit<Product, 'id'>) => {
        const { error } = await supabase.from('products').insert({ id: window.crypto.randomUUID(), name: product.name, is_active: product.isActive });
        if (error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const updateProduct = useCallback(async (productId: string, updates: Partial<Product>) => {
        const { error } = await supabase.from('products').update({ name: updates.name, is_active: updates.isActive }).eq('id', productId);
        if (error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const addDriver = useCallback(async (driver: Omit<Driver, 'id'>) => {
        const { error } = await supabase.from('drivers').insert({ name: driver.name, plate_number: driver.plateNumber, is_active: driver.isActive });
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const updateDriver = useCallback(async (driverId: number, updates: Partial<Driver>) => {
        const { error } = await supabase.from('drivers').update({ name: updates.name, plate_number: updates.plateNumber, is_active: updates.isActive }).eq('id', driverId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const deleteDriver = useCallback(async (driverId: number) => {
        const { error } = await supabase.from('drivers').delete().eq('id', driverId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const addRegion = useCallback(async (region: Omit<Region, 'id'>) => {
        const { error } = await supabase.from('regions').insert({ id: window.crypto.randomUUID(), name: region.name, diesel_liter_price: region.dieselLiterPrice, diesel_liters: region.dieselLiters, zaitri_fee: region.zaitriFee });
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const updateRegion = useCallback(async (regionId: string, updates: Partial<Region>) => {
        const { error } = await supabase.from('regions').update({ name: updates.name, diesel_liter_price: updates.dieselLiterPrice, diesel_liters: updates.dieselLiters, zaitri_fee: updates.zaitriFee }).eq('id', regionId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const deleteRegion = useCallback(async (regionId: string) => {
        const { error } = await supabase.from('regions').delete().eq('id', regionId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const addProductPrice = useCallback(async (price: Omit<ProductPrice, 'id'>) => {
        const { error } = await supabase.from('product_prices').insert({ id: window.crypto.randomUUID(), region_id: price.regionId, product_id: price.productId, price: price.price });
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const updateProductPrice = useCallback(async (priceId: string, updates: Partial<ProductPrice>) => {
        const { error } = await supabase.from('product_prices').update({ price: updates.price }).eq('id', priceId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const deleteProductPrice = useCallback(async (priceId: string) => {
        const { error } = await supabase.from('product_prices').delete().eq('id', priceId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const addShipment = useCallback(async (shipment: Omit<Shipment, 'id'>) => {
        if (!isOnline) {
            console.log('Offline: Queuing shipment creation.');
            // Create a temporary ID for local display
            const offlineShipment: Shipment = { ...shipment, id: `offline-${crypto.randomUUID()}`, isPendingSync: true };
            
            const currentShipments = getFromCache<Shipment[]>('shipments', []);
            const updatedShipments = [offlineShipment, ...currentShipments]; // Add to top
            setShipments(updatedShipments);
            setToCache('shipments', updatedShipments);

            const mutationQueue = getFromCache<{type: string, payload: any}[]>('mutationQueue', []);
            mutationQueue.push({ type: 'addShipment', payload: offlineShipment });
            setToCache('mutationQueue', mutationQueue);
            return;
        }

        const { products, ...shipmentData } = shipment;
        // Cast to any to avoid TS error about Partial<Update> not matching Insert required fields
        const shipmentToInsert = { ...shipmentToRow(shipmentData), id: crypto.randomUUID(), created_by: currentUser?.id } as any;
        
        const { data: newShipmentData, error: shipmentError } = await supabase.from('shipments').insert(shipmentToInsert).select().single();
        if (shipmentError) throw shipmentError;
        
        const shipmentProductsToInsert = products.map(p => ({ 
            shipment_id: newShipmentData.id, 
            product_id: p.productId, 
            product_name: p.productName, 
            carton_count: p.cartonCount, 
            product_wage_price: p.productWagePrice 
        }));
        
        const { error: productsError } = await supabase.from('shipment_products').insert(shipmentProductsToInsert);
        if (productsError) { 
            console.error("Failed to insert products for shipment:", newShipmentData.id, productsError); 
            // Ideally delete the shipment if product insertion fails to maintain integrity, but for now throwing error.
            throw productsError; 
        }
        
        await fetchAllData();
    }, [currentUser, fetchAllData, isOnline]);

    const updateShipment = useCallback(async (shipmentId: string, updates: Partial<Shipment>) => {
        if (!isOnline) {
            console.log('Offline: Queuing shipment update.');
            
            // Optimistically update local state
            const updatedShipments = shipments.map(s => 
                s.id === shipmentId ? { ...s, ...updates } : s
            );
            setShipments(updatedShipments);
            setToCache('shipments', updatedShipments);

            // Queue the mutation
            const mutationQueue = getFromCache<{type: string, payload: any}[]>('mutationQueue', []);
            mutationQueue.push({ type: 'updateShipment', payload: { shipmentId, updates } });
            setToCache('mutationQueue', mutationQueue);
            return;
        }
        const { products, ...shipmentUpdates } = updates;
        const updateRow = shipmentToRow(shipmentUpdates);
        const { error } = await supabase.from('shipments').update(updateRow).eq('id', shipmentId);
        if(error) throw error;
        await fetchAllData();
    }, [fetchAllData, isOnline, shipments]);
    
    const updateUser = useCallback(async (userId: string, updates: Partial<User>) => {
        const { error } = await supabase.from('users').update({ is_active: updates.isActive }).eq('id', userId);
        if (error) throw error;
        await fetchAllData();
    }, [fetchAllData]);

    const addNotification = useCallback(async (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
         // Notifications are fire-and-forget, mostly relevant for online users.
         // If offline, we could queue them, but for simplicity we'll skip or only try if online.
         if (!isOnline) return; 
        const { error } = await supabase.from('notifications').insert({ id: window.crypto.randomUUID(), timestamp: new Date().toISOString(), message: notification.message, category: notification.category, target_roles: notification.targetRoles, target_user_ids: notification.targetUserIds });
        if (error) throw error;
        // Don't refetch all data just for a notification sent
    }, [isOnline]);

    const markNotificationAsRead = useCallback(async (notificationId: string) => {
        const originalNotifications = [...notifications];
        setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, read: true } : n));
        if (!isOnline) return; // Optimistic update offline
        
        const { error } = await supabase.from('notifications').update({ read: true }).eq('id', notificationId);
        if (error) {
            console.error("Failed to mark notification as read:", error);
            setNotifications(originalNotifications);
        }
    }, [notifications, isOnline]);

    const markAllNotificationsAsRead = useCallback(async () => {
        const unreadIds = notifications.filter(n => !n.read).map(n => n.id);
        if (unreadIds.length === 0) return;
        const originalNotifications = [...notifications];
        setNotifications(prev => prev.map(n => unreadIds.includes(n.id) ? { ...n, read: true } : n));
        
        if (!isOnline) return; // Optimistic update offline

        const { error } = await supabase.from('notifications').update({ read: true }).in('id', unreadIds);
        if (error) {
            console.error("Failed to mark all notifications as read:", error);
            setNotifications(originalNotifications);
        }
    }, [notifications, isOnline]);

    const addUser = useCallback(async () => { console.warn("Function not implemented"); return null; }, []);
    
    const value = useMemo(() => ({
        currentUser, handleLogout, users, addUser, updateUser,
        products, addProduct, updateProduct,
        drivers, addDriver, updateDriver, deleteDriver,
        regions, addRegion, updateRegion, deleteRegion,
        shipments, addShipment, updateShipment,
        productPrices, addProductPrice, updateProductPrice, deleteProductPrice,
        notifications, addNotification, markNotificationAsRead, markAllNotificationsAsRead,
        accountantPrintAccess, setAccountantPrintAccess, isPrintHeaderEnabled, setIsPrintHeaderEnabled,
        appName, setAppName, companyName, setCompanyName, companyAddress, setCompanyAddress, companyPhone, setCompanyPhone,
        companyLogo, setCompanyLogo, isTimeWidgetVisible, setIsTimeWidgetVisible,
        loading, error, isOnline, isSyncing,
    }), [
        currentUser, handleLogout, users, addUser, updateUser,
        products, addProduct, updateProduct,
        drivers, addDriver, updateDriver, deleteDriver,
        regions, addRegion, updateRegion, deleteRegion,
        shipments, addShipment, updateShipment,
        productPrices, addProductPrice, updateProductPrice, deleteProductPrice,
        notifications, addNotification, markNotificationAsRead, markAllNotificationsAsRead,
        accountantPrintAccess, isPrintHeaderEnabled, appName, companyName, companyAddress, companyPhone, companyLogo, isTimeWidgetVisible,
        loading, error, isOnline, isSyncing, setAccountantPrintAccess, setIsPrintHeaderEnabled, setAppName, setCompanyName, setCompanyAddress, setCompanyPhone, setCompanyLogo, setIsTimeWidgetVisible
    ]);

    return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};
