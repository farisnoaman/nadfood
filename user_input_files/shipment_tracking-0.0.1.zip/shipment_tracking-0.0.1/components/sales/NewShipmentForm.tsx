import React, { useState } from 'react';
import { Region, Driver, Product, ShipmentProduct, Shipment, ShipmentStatus, ProductPrice, Role, NotificationCategory } from '../../types';
import { calculateInitialShipmentValues } from '../../utils/calculations';
import Button from '../common/Button';
import Card from '../common/Card';
import Input from '../common/Input';
import { Icons } from '../Icons';
import SearchableSelect from '../common/SearchableSelect';
import { useAppContext } from '../../context/AppContext';

/**
 * A dedicated component for a single product row in the New Shipment Form.
 * It encapsulates the logic for selecting a product, entering carton count, and displaying price info.
 */
const ProductInputRow: React.FC<{
  index: number;
  product: ShipmentProduct;
  activeProducts: Product[];
  productPrices: ProductPrice[];
  regionId: string;
  onProductChange: <K extends keyof ShipmentProduct>(index: number, field: K, value: ShipmentProduct[K]) => void;
  onRemove: (index: number) => void;
  isRemovable: boolean;
}> = ({ index, product, activeProducts, productPrices, regionId, onProductChange, onRemove, isRemovable }) => {
    
  const priceInfo = productPrices.find((p: ProductPrice) => p.regionId === regionId && p.productId === product.productId);
  const price = priceInfo ? priceInfo.price : null;

  return (
    <div className="relative mt-4 p-4 border dark:border-secondary-600 rounded-lg space-y-3 bg-secondary-50/50 dark:bg-secondary-800/20">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SearchableSelect
          label="المنتج"
          options={activeProducts.map((p: Product) => ({ value: p.id, label: p.name }))}
          value={product.productId}
          onChange={val => onProductChange(index, 'productId', String(val))}
          placeholder="ابحث أو اختر منتج"
        />
        <div className="relative">
          <Input 
            label="عدد الكراتين" 
            type="number" 
            min="0" 
            value={product.cartonCount} 
            onChange={e => onProductChange(index, 'cartonCount', Math.max(0, Number(e.target.value)))} 
          />
          {product.productId && price === null && (
            <div className="absolute top-0 end-0 pt-1 pe-2 text-yellow-500" title="لا يوجد سعر محدد لهذا المنتج في المنطقة المختارة. سيتم إعلام المدير.">
              <Icons.AlertTriangle className="h-5 w-5" />
            </div>
          )}
        </div>
      </div>
      <div className="flex justify-between items-center bg-secondary-100 dark:bg-secondary-800 p-2 rounded-md">
        <div className="text-sm">
          <span>السعر للكرتون: </span>
          <span className="font-semibold">{price !== null ? `${price} ر.ي` : 'غير محدد'}</span>
        </div>
        <div className="text-sm">
          <span>الإجمالي: </span>
          <span className="font-semibold text-primary-600 dark:text-primary-400">{(price !== null ? price * product.cartonCount : 0).toLocaleString('en-US')} ر.ي</span>
        </div>
      </div>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={() => onRemove(index)}
        disabled={!isRemovable}
        className="absolute top-2 left-2 !p-1 h-auto text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50"
        aria-label="إزالة المنتج"
      >
        <Icons.X className="h-5 w-5" />
      </Button>
    </div>
  );
};


const NewShipmentForm: React.FC = () => {
  const { regions, drivers, products: allProducts, addShipment, productPrices, addNotification, currentUser } = useAppContext();
  
  const [orderDate, setOrderDate] = useState(new Date().toISOString().split('T')[0]);
  const [salesOrder, setSalesOrder] = useState(`SO-${new Date().getFullYear()}${(Math.floor(Math.random() * 900000) + 100000)}`);
  const [regionId, setRegionId] = useState(regions[0]?.id || '');
  const [driverId, setDriverId] = useState<number | ''>('');
  const [selectedProducts, setSelectedProducts] = useState<ShipmentProduct[]>([{ productId: '', productName: '', cartonCount: 0 }]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  
  const activeProducts = allProducts.filter((p: Product) => p.isActive ?? true);

  const handleAddProduct = () => {
    setSelectedProducts([...selectedProducts, { productId: '', productName: '', cartonCount: 0 }]);
  };

  const handleRemoveProduct = (index: number) => {
    const newProducts = selectedProducts.filter((_, i) => i !== index);
    setSelectedProducts(newProducts);
  };

  const handleProductChange = <K extends keyof ShipmentProduct>(index: number, field: K, value: ShipmentProduct[K]) => {
    const newProducts = [...selectedProducts];
    newProducts[index][field] = value;
    if (field === 'productId') {
        const product = allProducts.find((p: Product) => p.id === value);
        newProducts[index].productName = product?.name || '';
    }
    setSelectedProducts(newProducts);
  };
  
  const getSelectedDriver = () => drivers.find((d: Driver) => d.id === driverId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSubmitting(true);

    if (!orderDate || !salesOrder || !regionId || !driverId || selectedProducts.some(p => !p.productId || p.cartonCount <= 0)) {
        setError('يرجى ملء جميع الحقول المطلوبة والتأكد من أن عدد الكراتين أكبر من صفر.');
        setSubmitting(false);
        return;
    }
    
    const finalProducts = selectedProducts.filter(p => p.productId && p.cartonCount > 0);
    
    const notificationPromises: Promise<void>[] = [];
    finalProducts.forEach(product => {
        const priceExists = productPrices.some((pp: ProductPrice) => pp.regionId === regionId && pp.productId === product.productId);
        if (!priceExists) {
            const region = regions.find((r: Region) => r.id === regionId);
            const productDetails = allProducts.find((p: Product) => p.id === product.productId);
            if(region && productDetails) {
                notificationPromises.push(addNotification({
                    message: `تنبيه: مطلوب تحديد سعر للمنتج "${productDetails.name}" في منطقة "${region.name}".`,
                    category: NotificationCategory.PRICE_ALERT,
                    targetRoles: [Role.ADMIN]
                }));
            }
        }
    });

    try {
        const newShipmentBase: Omit<Shipment, 'id' | 'entryTimestamp' | 'status'> = {
            orderDate,
            salesOrder,
            regionId,
            driverId: driverId,
            products: finalProducts,
            hasMissingPrices: false,
        };
        
        const calculatedValues = calculateInitialShipmentValues(newShipmentBase, regions, productPrices);
        
        const newShipment: Omit<Shipment, 'id'> = {
            ...newShipmentBase,
            entryTimestamp: new Date().toISOString(),
            status: ShipmentStatus.FROM_SALES,
            ...calculatedValues,
        };

        await addShipment(newShipment);
        
        // Group notifications together
        notificationPromises.push(addNotification({ message: `شحنة جديدة (${newShipment.salesOrder}) تم استلامها من المبيعات.`, category: NotificationCategory.USER_ACTION, targetRoles: [Role.ACCOUNTANT] }));
        if (currentUser) {
            notificationPromises.push(addNotification({ message: `تم إرسال شحنتك (${newShipment.salesOrder}) بنجاح للمراجعة.`, category: NotificationCategory.USER_ACTION, targetUserIds: [currentUser.id] }));
        }
        
        await Promise.all(notificationPromises);
        
        setSuccess(`تم إرسال الشحنة بنجاح! رقم الأمر: ${newShipment.salesOrder}`);

        // Reset the form
        setSalesOrder(`SO-${new Date().getFullYear()}${(Math.floor(Math.random() * 900000) + 100000)}`);
        setRegionId(regions[0]?.id || '');
        setDriverId('');
        setSelectedProducts([{ productId: '', productName: '', cartonCount: 0 }]);

    } catch (err: any) {
        console.error("Failed to submit shipment:", err);
        setError(`فشل إرسال الشحنة: ${err.message}`);
    } finally {
        setSubmitting(false);
    }
  };

  return (
    <Card title="بيانات الشحنة الجديدة">
      <form onSubmit={handleSubmit} className="space-y-8">
        {error && <div className="p-3 bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-200 rounded-md">{error}</div>}
        {success && <div className="p-3 bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-200 rounded-md">{success}</div>}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="تاريخ الأمر" type="date" value={orderDate} onChange={e => setOrderDate(e.target.value)} required />
            <Input label="أمر المبيعات" type="text" value={salesOrder} onChange={e => setSalesOrder(e.target.value)} required />
            <SearchableSelect
                id="region"
                label="المنطقة"
                options={regions.map((r: Region) => ({ value: r.id, label: r.name }))}
                value={regionId}
                onChange={(val) => setRegionId(String(val))}
                placeholder="ابحث أو اختر منطقة"
            />
            <SearchableSelect
                id="driver"
                label="اسم السائق"
                options={drivers.filter((d: Driver) => d.isActive ?? true).map((d: Driver) => ({ value: d.id, label: d.name }))}
                value={driverId}
                onChange={(val) => setDriverId(Number(val))}
                placeholder="ابحث أو اختر سائق"
            />
            {driverId && (
                <Input label="رقم اللوحة" type="text" value={getSelectedDriver()?.plateNumber || ''} readOnly disabled />
            )}
        </div>

        <div className="border-t border-secondary-200 dark:border-secondary-700 pt-6">
          <h3 className="text-lg font-medium">المنتجات</h3>
          {selectedProducts.map((product, index) => (
            <ProductInputRow
              key={index}
              index={index}
              product={product}
              activeProducts={activeProducts}
              productPrices={productPrices}
              regionId={regionId}
              onProductChange={handleProductChange}
              onRemove={handleRemoveProduct}
              isRemovable={selectedProducts.length > 1}
            />
          ))}
          <Button type="button" variant="secondary" onClick={handleAddProduct} className="mt-4">
            <Icons.Plus className="ml-2 h-5 w-5" />
            إضافة منتج آخر
          </Button>
        </div>

        <div className="flex justify-end pt-6 border-t border-secondary-200 dark:border-secondary-700">
            <Button type="submit" size="lg" disabled={submitting}>
                {submitting ? 'جاري الإرسال...' : (
                    <>
                        <Icons.Send className="ml-2 h-5 w-5" />
                        إرسال البيانات
                    </>
                )}
            </Button>
        </div>
      </form>
    </Card>
  );
};

export default NewShipmentForm;