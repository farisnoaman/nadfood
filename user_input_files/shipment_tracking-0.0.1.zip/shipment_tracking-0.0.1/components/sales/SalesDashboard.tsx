
import React from 'react';
import NewShipmentForm from './NewShipmentForm';

const SalesDashboard: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">لوحة تحكم المبيعات</h1>
      <NewShipmentForm />
    </div>
  );
};

export default SalesDashboard;
