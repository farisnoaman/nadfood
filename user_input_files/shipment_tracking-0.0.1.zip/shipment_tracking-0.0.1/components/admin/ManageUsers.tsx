
import React, { useState, useMemo } from 'react';
import { User, Role } from '../../types';
import Card from '../common/Card';
import Button from '../common/Button';
import Input from '../common/Input';
import { Icons } from '../Icons';
import Modal from '../common/Modal';
import { useAppContext } from '../../context/AppContext';
import SearchableSelect from '../common/SearchableSelect';
import { supabase } from '../../utils/supabaseClient';

const ManageUsers: React.FC = () => {
  const { users, updateUser, currentUser } = useAppContext();
  
  // Sorting state
  const [sortBy, setSortBy] = useState<'username' | 'role' | 'status'>('username');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // State for password change modal
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [changePasswordMessage, setChangePasswordMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // State for add user modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [addUserPassword, setAddUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState<Role>(Role.SALES);
  const [addUserError, setAddUserError] = useState('');
  
  // State for activation/deactivation modal
  const [userToToggleStatus, setUserToToggleStatus] = useState<User | null>(null);

  const sortedUsers = useMemo(() => {
    const filtered = users.filter((u: User) => u.id !== currentUser?.id);
    return filtered.sort((a, b) => {
      let valA: string | number = '';
      let valB: string | number = '';

      if (sortBy === 'username') {
        valA = a.username.toLowerCase();
        valB = b.username.toLowerCase();
      } else if (sortBy === 'role') {
        valA = a.role;
        valB = b.role;
      } else if (sortBy === 'status') {
        // Treat active (true) as 1, inactive (false) as 0
        valA = (a.isActive ?? true) ? 1 : 0;
        valB = (b.isActive ?? true) ? 1 : 0;
      }

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [users, currentUser, sortBy, sortOrder]);

  const handlePasswordChange = async () => {
    if (!selectedUser || !newPassword) {
      setChangePasswordMessage("الرجاء إدخال كلمة مرور جديدة.");
      return;
    }
    setIsSubmitting(true);
    // Note: Updating other users' passwords requires admin privileges on Supabase.
    // This is often done via a server-side function for security.
    // The client-side supabase.auth.updateUser only works for the currently logged-in user.
    // This is a placeholder for a more secure server-side implementation.
    console.warn(`Password change for ${selectedUser.username} initiated. This requires server-side logic in a real application.`);
    setChangePasswordMessage(`تم إرسال طلب تغيير كلمة مرور ${selectedUser.username}. (يتطلب تنفيذ من جهة الخادم)`);
    setNewPassword('');
    setIsSubmitting(false);
    setTimeout(() => {
        setSelectedUser(null);
        setChangePasswordMessage('');
    }, 3000);
  };

  const handleCloseAddModal = () => {
    setIsAddModalOpen(false);
    setNewUsername('');
    setNewUserEmail('');
    setAddUserPassword('');
    setNewUserRole(Role.SALES);
    setAddUserError('');
  };

  const handleAddNewUser = async () => {
    setAddUserError('');
    if (!newUsername.trim() || !addUserPassword.trim() || !newUserEmail.trim()) {
      setAddUserError('يرجى ملء جميع الحقول.');
      return;
    }
    setIsSubmitting(true);
    
    const { data, error } = await supabase.auth.signUp({
        email: newUserEmail,
        password: addUserPassword,
    });

    if (error) {
        setAddUserError(error.message);
    } else if (data.user) {
        // Now create the users entry
        const { error: profileError } = await supabase.from('users').insert({
            id: data.user.id,
            username: newUsername.trim(),
            role: newUserRole,
            is_active: true,
        });

        if (profileError) {
            setAddUserError(`فشل إنشاء ملف المستخدم: ${profileError.message}`);
        } else {
            handleCloseAddModal();
            // The context will refetch data automatically after a short delay or via real-time subscription
        }
    }
    setIsSubmitting(false);
  };
  
  const confirmToggleUserStatus = async () => {
    if (!userToToggleStatus) return;
    setIsSubmitting(true);
    await updateUser(userToToggleStatus.id, { isActive: !(userToToggleStatus.isActive ?? true) });
    setUserToToggleStatus(null);
    setIsSubmitting(false);
  };
  
  return (
    <>
      <Card title="إدارة المستخدمين">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
            <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="min-w-[160px]">
                    <SearchableSelect 
                        label="ترتيب حسب"
                        options={[
                            { value: 'username', label: 'اسم المستخدم' },
                            { value: 'role', label: 'الدور' },
                            { value: 'status', label: 'الحالة' },
                        ]}
                        value={sortBy}
                        onChange={(val) => setSortBy(val as any)}
                    />
                </div>
                <div className="mt-6">
                     <Button variant="secondary" onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')} title={sortOrder === 'asc' ? 'تصاعدي' : 'تنازلي'}>
                        {sortOrder === 'asc' ? <Icons.ArrowUp className="h-5 w-5" /> : <Icons.ArrowDown className="h-5 w-5" />}
                    </Button>
                </div>
            </div>
            <div className="w-full sm:w-auto mt-auto">
                <Button onClick={() => setIsAddModalOpen(true)} className="w-full sm:w-auto">
                    <Icons.UserPlus className="ml-2 h-4 w-4" />
                    إضافة مستخدم جديد
                </Button>
            </div>
        </div>

        <div className="space-y-3">
          {sortedUsers.map((user: User) => (
            <div key={user.id} className={`flex flex-col sm:flex-row justify-between sm:items-center p-3 bg-secondary-100 dark:bg-secondary-700 rounded-md transition-opacity ${user.isActive ?? true ? '' : 'opacity-60'}`}>
              <div>
                <p className="font-semibold">{user.username}</p>
                <div className="flex items-center text-sm mt-1 sm:mt-0">
                  <p className="text-secondary-500">{user.role}</p>
                  <span className={`mx-2 px-2 py-0.5 text-xs rounded-full ${user.isActive ?? true ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'}`}>
                      {user.isActive ?? true ? 'نشط' : 'غير نشط'}
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-1 rtl:space-x-reverse mt-2 sm:mt-0 self-end sm:self-center">
                  <Button size="sm" variant="ghost" onClick={() => setUserToToggleStatus(user)} title={user.isActive ?? true ? 'إلغاء التفعيل' : 'تفعيل'}>
                      {user.isActive ?? true
                          ? <Icons.CircleX className="h-5 w-5 text-red-500" />
                          : <Icons.CircleCheck className="h-5 w-5 text-green-500" />
                      }
                  </Button>
                  <Button size="sm" onClick={() => setSelectedUser(user)}>
                      <Icons.KeyRound className="ml-2 h-4 w-4" />
                      تغيير كلمة السر
                  </Button>
              </div>
            </div>
          ))}
          {sortedUsers.length === 0 && (
              <p className="text-center text-secondary-500 py-4">لا يوجد مستخدمين آخرين.</p>
          )}
        </div>

        {selectedUser && (
          <Modal isOpen={!!selectedUser} onClose={() => setSelectedUser(null)} title={`تغيير كلمة مرور ${selectedUser.username}`}>
            <div className="space-y-4">
              {changePasswordMessage && <p className="text-green-600 dark:text-green-400 text-center">{changePasswordMessage}</p>}
              <Input 
                label="كلمة المرور الجديدة"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="********"
              />
              <div className="flex justify-end gap-3">
                  <Button variant="secondary" onClick={() => setSelectedUser(null)}>إلغاء</Button>
                  <Button onClick={handlePasswordChange} disabled={isSubmitting}>{isSubmitting ? 'جاري الحفظ...' : 'حفظ التغييرات'}</Button>
              </div>
            </div>
          </Modal>
        )}

        <Modal isOpen={isAddModalOpen} onClose={handleCloseAddModal} title="إضافة مستخدم جديد">
          <div className="space-y-4">
            {addUserError && <p className="text-red-500 text-sm text-center">{addUserError}</p>}
            <Input 
              label="اسم المستخدم"
              type="text"
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              required
            />
            <Input 
              label="البريد الإلكتروني (للدخول)"
              type="email"
              value={newUserEmail}
              onChange={(e) => setNewUserEmail(e.target.value)}
              required
            />
            <Input 
              label="كلمة المرور"
              type="password"
              value={addUserPassword}
              onChange={(e) => setAddUserPassword(e.target.value)}
              placeholder="********"
              required
            />
            <SearchableSelect
              label="الدور"
              options={Object.values(Role).map(role => ({ value: role, label: role }))}
              value={newUserRole}
              onChange={(val) => setNewUserRole(val as Role)}
            />
            <div className="flex justify-end gap-3 pt-4">
              <Button variant="secondary" onClick={handleCloseAddModal}>إلغاء</Button>
              <Button onClick={handleAddNewUser} disabled={isSubmitting}>{isSubmitting ? 'جاري الإضافة...' : 'إضافة المستخدم'}</Button>
            </div>
          </div>
        </Modal>
      </Card>
      <Modal isOpen={!!userToToggleStatus} onClose={() => setUserToToggleStatus(null)} title="تأكيد تغيير الحالة">
          <div className="text-center">
              <Icons.AlertTriangle className="mx-auto h-12 w-12 text-yellow-500" />
              <p className="mt-4">
                  هل أنت متأكد من رغبتك في 
                  {userToToggleStatus?.isActive ?? true ? ' إلغاء تفعيل ' : ' تفعيل '}
                  المستخدم 
                  <span className="font-bold"> {userToToggleStatus?.username}</span>؟
              </p>
              <p className="text-sm text-secondary-500">
                  {userToToggleStatus?.isActive ?? true
                      ? 'لن يتمكن المستخدم من تسجيل الدخول بعد إلغاء التفعيل.'
                      : 'سيتمكن المستخدم من تسجيل الدخول بعد التفعيل.'}
              </p>
              <div className="mt-6 flex justify-center gap-4">
                  <Button variant="secondary" onClick={() => setUserToToggleStatus(null)}>إلغاء</Button>
                  <Button variant="primary" onClick={confirmToggleUserStatus} disabled={isSubmitting}>{isSubmitting ? 'جاري التغيير...' : 'نعم، تأكيد'}</Button>
              </div>
          </div>
      </Modal>
    </>
  );
};

export default ManageUsers;