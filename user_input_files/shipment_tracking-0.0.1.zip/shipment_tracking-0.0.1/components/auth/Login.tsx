import React, { useState } from 'react';
import Button from '../common/Button';
import Input from '../common/Input';
import Card from '../common/Card';
import { Icons } from '../Icons';
import TimeWidget from '../common/TimeWidget';
import { useAppContext } from '../../context/AppContext';
import { supabase } from '../../utils/supabaseClient';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { isTimeWidgetVisible } = useAppContext();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
          if (error.message.includes("Invalid login credentials")) {
              setError('اسم المستخدم أو كلمة المرور غير صحيحة');
          } else {
              setError(error.message);
          }
      }
      // onAuthStateChange in AppContext will handle successful login
    } catch (err) {
        setError('حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.');
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-secondary-100 dark:bg-secondary-900">
      {isTimeWidgetVisible && <TimeWidget />}
      <div className="flex-grow flex items-center justify-center">
        <div className="w-full max-w-md px-4">
          <div className="flex justify-center mb-6">
              <Icons.Truck className="h-12 w-12 text-primary-600" />
          </div>
          <Card>
              <h2 className="text-2xl font-bold text-center text-secondary-900 dark:text-secondary-100 mb-6">تسجيل الدخول</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
              {error && <p className="text-red-500 text-sm text-center">{error}</p>}
              <Input
                  id="email"
                  label="البريد الإلكتروني"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  Icon={Icons.User}
              />
              <Input
                  id="password"
                  label="كلمة المرور"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  Icon={Icons.KeyRound}
              />
              <Button type="submit" className="w-full" size="lg" disabled={loading}>
                  {loading ? 'جاري الدخول...' : (
                      <>
                        <Icons.LogIn className="ml-2 h-5 w-5" />
                        دخول
                      </>
                  )}
              </Button>
              </form>
          </Card>
        </div>
      </div>
      <footer className="py-4 px-4 text-center text-sm text-secondary-500 dark:text-secondary-400">
        <p>Copyright Reserved @ {new Date().getFullYear()}</p>
        <p>Designed with ❤️ by Faris Alsolmi</p>
      </footer>
    </div>
  );
};

export default Login;
