import React, { useState, useEffect } from 'react';
import { Shipment, ShipmentStatus, Role, NotificationCategory, Driver } from '../../types';
import { calculateAccountantValues, calculateInitialShipmentValues } from '../../utils/calculations';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Input from '../common/Input';
import { Icons } from '../Icons';
import { printShipmentDetails } from '../../utils/print';
import { useAppContext } from '../../context/AppContext';
import FieldValue from '../common/FieldValue';
import ProductDetails from '../common/ProductDetails';
import ShipmentStepper from '../common/ShipmentStepper';

// --- Helper Functions and Sub-components ---

/** Displays the initial summary of the shipment calculated from sales data. */
const InitialSummary: React.FC<{ shipment: Shipment }> = ({ shipment }) => (
  <div className="bg-secondary-100 dark:bg-secondary-900 p-3 rounded-md">
    <h4 className="font-bold mb-2">معلومات أساسية</h4>
    <FieldValue label="إجمالي الأجر" value={shipment.totalWage} />
    <FieldValue label="إجمالي الديزل" value={shipment.totalDiesel} />
    <FieldValue label="رسوم زعيتري" value={shipment.zaitriFee} />
    <FieldValue label="مصروفات إدارية" value={shipment.adminExpenses} />
    <div className="font-bold mt-2"><FieldValue label="المبلغ المستحق" value={shipment.dueAmount} /></div>
  </div>
);

/** Section for accountant's deductions. Renders an editable form or a readonly view. */
const DeductionsSection: React.FC<{ isEditable: boolean; shipment: Shipment; onValueChange: (field: keyof Shipment, value: any) => void; }> = ({ isEditable, shipment, onValueChange }) => {
  if (isEditable) {
    return (
      <div className="space-y-4 pt-4 border-t dark:border-secondary-600">
        <h4 className="font-bold text-lg">قسم الخصميات</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="التالف" type="number" min="0" value={shipment.damagedValue || ''} onChange={e => onValueChange('damagedValue', e.target.value)} />
          <Input label="النقص" type="number" min="0" value={shipment.shortageValue || ''} onChange={e => onValueChange('shortageValue', e.target.value)} />
        </div>
        <Input label="خرج الطريق" type="number" min="0" value={shipment.roadExpenses || ''} onChange={e => onValueChange('roadExpenses', e.target.value)} />
        <div className="font-bold text-lg text-primary-600 dark:text-primary-400 p-3 bg-secondary-100 dark:bg-secondary-900 rounded">
          <FieldValue label="المبلغ المستحق بعد الخصم" value={shipment.dueAmountAfterDiscount} />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-secondary-100 dark:bg-secondary-900 p-3 rounded-md">
      <h4 className="font-bold mb-2">الخصميات</h4>
      <FieldValue label="التالف" value={shipment.damagedValue} />
      <FieldValue label="النقص" value={shipment.shortageValue} />
      <FieldValue label="خرج الطريق" value={shipment.roadExpenses} />
      <div className="font-bold mt-2"><FieldValue label="المبلغ المستحق بعد الخصم" value={shipment.dueAmountAfterDiscount} /></div>
    </div>
  );
};

/** A confirmation dialog for sending with zero deductions. */
const ConfirmationDialog: React.FC<{ isOpen: boolean; onClose: () => void; onConfirm: () => void; isSubmitting: boolean; }> = ({ isOpen, onClose, onConfirm, isSubmitting }) => (
    <Modal isOpen={isOpen} onClose={onClose} title="تأكيد الإرسال">
        <div className="p-4 text-center">
            <Icons.AlertTriangle className="mx-auto h-12 w-12 text-yellow-500" />
            <p className="mt-4">هل أنت متأكد من ترحيل البيانات بدون قيم للتالف أو النقص؟</p>
            <div className="mt-6 flex justify-center space-x-4 rtl:space-x-reverse">
                <Button variant="secondary" onClick={onClose} disabled={isSubmitting}>إلغاء</Button>
                <Button variant="primary" onClick={onConfirm} disabled={isSubmitting}>{isSubmitting ? 'جاري التأكيد...' : 'نعم، تأكيد'}</Button>
            </div>
        </div>
    </Modal>
);


// --- Main Modal Component ---

interface AccountantShipmentModalProps {
  shipment: Shipment;
  isOpen: boolean;
  onClose: () => void;
  isEditable: boolean;
}

const AccountantShipmentModal: React.FC<AccountantShipmentModalProps> = ({ shipment, isOpen, onClose, isEditable }) => {
  const { 
    updateShipment, addNotification, accountantPrintAccess, drivers, regions, productPrices,
    isPrintHeaderEnabled, companyName, companyAddress, companyPhone, companyLogo, currentUser
  } = useAppContext();
  const [currentShipment, setCurrentShipment] = useState<Shipment>({ ...shipment });
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isProductsExpanded, setIsProductsExpanded] = useState(false);
  const [showMissingPriceDialog, setShowMissingPriceDialog] = useState(false);
  const [productWithMissingPrice, setProductWithMissingPrice] = useState<{name: string, region: string} | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [recalculating, setRecalculating] = useState(false);
  const [recalcMessage, setRecalcMessage] = useState('');

  useEffect(() => {
    setCurrentShipment({ ...shipment });
    setIsProductsExpanded(false); // Reset on new shipment
    setRecalcMessage('');
  }, [shipment]);

  const handleValueChange = (field: keyof Shipment, value: any) => {
    const numericValue = Math.max(0, Number(value));
    const updatedShipment = { ...currentShipment, [field]: numericValue };
    const calculated = calculateAccountantValues(updatedShipment);
    setCurrentShipment({ ...updatedShipment, ...calculated });
  };

  const handleSaveDraft = async () => {
    setIsSubmitting(true);
    try {
        const draftShipment = { ...currentShipment, status: ShipmentStatus.DRAFT };
        await updateShipment(draftShipment.id, draftShipment);
        onClose();
    } catch(err) {
        console.error("Failed to save draft:", err);
        alert("فشل حفظ المسودة.");
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const handleSend = () => {
    // Check for missing or zero prices before proceeding
    for (const product of currentShipment.products) {
        const priceInfo = productPrices.find(pp => pp.regionId === currentShipment.regionId && pp.productId === product.productId);
        if (!priceInfo || priceInfo.price <= 0) {
            const regionName = regions.find(r => r.id === currentShipment.regionId)?.name || currentShipment.regionId;
            setProductWithMissingPrice({ name: product.productName, region: regionName });
            setShowMissingPriceDialog(true);
            return; // Stop the submission process
        }
    }

    if ((currentShipment.damagedValue === 0 || !currentShipment.damagedValue) && (currentShipment.shortageValue === 0 || !currentShipment.shortageValue)) {
      setShowConfirmation(true);
    } else {
      confirmAndSend();
    }
  };
  
  const handleRecalculatePrices = async () => {
    setRecalculating(true);
    setRecalcMessage('');

    // Recalculate initial values using the latest prices from context
    const recalculatedInitial = calculateInitialShipmentValues(currentShipment, regions, productPrices);
    
    // Merge the new initial values
    let updatedShipment = {
        ...currentShipment,
        ...recalculatedInitial,
    };

    // Recalculate accountant values based on the new dueAmount
    const recalculatedAccountant = calculateAccountantValues(updatedShipment);

    // Merge accountant values
    updatedShipment = {
        ...updatedShipment,
        ...recalculatedAccountant,
    };

    setCurrentShipment(updatedShipment);

    // Provide feedback
    if (recalculatedInitial.hasMissingPrices) {
        setRecalcMessage('فشل التحديث. ما زالت هناك أسعار مفقودة.');
    } else {
        setRecalcMessage('تم تحديث الأسعار والحسابات بنجاح!');
    }

    setRecalculating(false);
    
    // Hide message after a few seconds
    setTimeout(() => setRecalcMessage(''), 4000);
  };


  const handleNotifyAdminAndCloseDialog = async () => {
    if (!productWithMissingPrice) return;

    await addNotification({
        message: `مطلوب تحديد سعر للمنتج "${productWithMissingPrice.name}" في منطقة "${productWithMissingPrice.region}". تم حظر تقديم الشحنة ${currentShipment.salesOrder} لهذا السبب.`,
        category: NotificationCategory.PRICE_ALERT,
        targetRoles: [Role.ADMIN]
    });
    setShowMissingPriceDialog(false);
    setProductWithMissingPrice(null);
  };
  
  const confirmAndSend = async () => {
    setIsSubmitting(true);
    setShowConfirmation(false);
    try {
        const initialRecalculatedValues = calculateInitialShipmentValues(currentShipment, regions, productPrices);
        let shipmentWithNewInitialValues = { ...currentShipment, ...initialRecalculatedValues };
        const accountantRecalculatedValues = calculateAccountantValues(shipmentWithNewInitialValues);
        
        const finalShipmentToSend = {
            ...shipmentWithNewInitialValues,
            ...accountantRecalculatedValues,
            status: ShipmentStatus.SENT_TO_ADMIN
        };
        
        await updateShipment(finalShipmentToSend.id, finalShipmentToSend);
        await addNotification({ message: `تم ترحيل الشحنة (${finalShipmentToSend.salesOrder}) إلى المدير للمراجعة.`, category: NotificationCategory.USER_ACTION, targetRoles: [Role.ADMIN] });
        onClose();
    } catch (err) {
        console.error("Failed to send to admin:", err);
        alert("فشل إرسال الشحنة للمدير.");
    } finally {
        setIsSubmitting(false);
    }
  };

  const handlePrint = () => {
    if (!currentUser) return;
    const driver = drivers.find((d: Driver) => d.id === currentShipment.driverId);
    const companyDetails = { companyName, companyAddress, companyPhone, companyLogo, isPrintHeaderEnabled };
    printShipmentDetails(currentShipment, driver, companyDetails, currentUser);
  };

  const isFinal = currentShipment.status === ShipmentStatus.FINAL || currentShipment.status === ShipmentStatus.FINAL_MODIFIED;

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} title={`تفاصيل الشحنة: ${shipment.salesOrder}`} size="lg">
        <div className="space-y-4 p-1">
          <ShipmentStepper status={currentShipment.status} />
          
          {isEditable && currentShipment.hasMissingPrices && (
            <div className="p-3 mb-2 bg-yellow-100 dark:bg-yellow-900/40 border border-yellow-300 dark:border-yellow-700 rounded-md text-center">
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <div className="flex items-center">
                        <Icons.AlertTriangle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 ml-2" />
                        <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-200">
                            تحذير: هذه الشحنة تحتوي على أسعار مفقودة.
                        </p>
                    </div>
                    <Button onClick={handleRecalculatePrices} disabled={recalculating} size="sm">
                        {recalculating ? 'جاري الحساب...' : (
                            <>
                                <Icons.ChevronsRightLeft className="ml-2 h-4 w-4" />
                                إعادة حساب الأسعار
                            </>
                        )}
                    </Button>
                </div>
                {recalcMessage && <p className={`text-sm mt-2 font-medium ${recalcMessage.includes('فشل') ? 'text-red-600' : 'text-green-700 dark:text-green-300'}`}>{recalcMessage}</p>}
            </div>
          )}

          <InitialSummary shipment={currentShipment} />
          
          <ProductDetails
            products={currentShipment.products}
            isExpanded={isProductsExpanded}
            onToggle={() => setIsProductsExpanded(!isProductsExpanded)}
            title="المنتجات"
          />

          <DeductionsSection
            isEditable={isEditable}
            shipment={currentShipment}
            onValueChange={handleValueChange}
          />

          <div className="flex flex-wrap justify-between items-center gap-3 pt-4 border-t dark:border-secondary-600">
              <div>
                  {isFinal && accountantPrintAccess && (
                      <Button variant="secondary" onClick={handlePrint}>
                          <Icons.Printer className="ml-2 h-4 w-4" />
                          طباعة
                      </Button>
                  )}
              </div>

              {isEditable && (
                <div className="flex justify-end space-x-3 rtl:space-x-reverse">
                  <Button variant="secondary" onClick={handleSaveDraft} disabled={isSubmitting}>
                    {isSubmitting ? 'جاري الحفظ...' : <> <Icons.Save className="ml-2 h-4 w-4" /> حفظ كمسودة </>}
                  </Button>
                  <Button variant="primary" onClick={handleSend} disabled={isSubmitting}>
                     {isSubmitting ? 'جاري الإرسال...' : <> <Icons.Send className="ml-2 h-4 w-4" /> إرسال للمدير </>}
                  </Button>
                </div>
              )}
          </div>
        </div>
      </Modal>
      <ConfirmationDialog 
        isOpen={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={confirmAndSend}
        isSubmitting={isSubmitting}
      />
      <Modal 
        isOpen={showMissingPriceDialog} 
        onClose={() => { setShowMissingPriceDialog(false); setProductWithMissingPrice(null); }} 
        title="سعر المنتج مفقود"
      >
        <div className="p-4 text-center">
            <Icons.AlertTriangle className="mx-auto h-12 w-12 text-yellow-500" />
            <p className="mt-4">تم منع الإرسال لأن سعر المنتج "{productWithMissingPrice?.name}" هو صفر أو غير محدد.</p>
            <div className="mt-6 flex justify-center">
                <Button variant="primary" onClick={handleNotifyAdminAndCloseDialog}>
                    موافق، إعلام المسؤول
                </Button>
            </div>
        </div>
      </Modal>
    </>
  );
};

export default AccountantShipmentModal;