
import { createClient } from '@supabase/supabase-js';
import { Database } from '../supabase/database.types';

const supabaseUrl = 'https://kjvzhzbxspgvvmktjwdi.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtqdnpoemJ4c3BndnZta3Rqd2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI2MjYyMTQsImV4cCI6MjA3ODIwMjIxNH0.xc1wMNg_q23ZbNhUm6oyKbUw_298y0xG9B8YBU6j2VI';

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);
